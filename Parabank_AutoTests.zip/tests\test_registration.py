
import time
import pytest
import allure

from selenium.webdriver.common.by import By

from pages.registration_page import RegistrationPage
from tests.test_data import get_registration_data
from metrics.metrics import save_metric


@allure.epic("Parabank")
@allure.feature("Регистрация пользователей")
class TestRegistration:

    def print_page_debug(self, driver, title):
        print(f"\n========== {title} ==========")
        print("URL:", driver.current_url)

        try:
            print(
                "ТЕКСТ СТРАНИЦЫ:",
                driver.find_element(By.TAG_NAME, "body").text
            )
        except Exception as error:
            print("Не удалось получить текст:", error)

        print("============================\n")

    @allure.title("Позитивный тест регистрации")
    @allure.description(
        "Проверка успешного создания нового пользователя"
    )
    @allure.severity(allure.severity_level.CRITICAL)
    @pytest.mark.positive
    @pytest.mark.registration
    def test_successful_registration(self, driver):

        data = get_registration_data()
        page = RegistrationPage(driver)

        start = time.perf_counter()

        page.open_registration()

        page_load_time = (time.perf_counter() - start) * 1000

        save_metric(
            "registration_page_load",
            page_load_time
        )

        page.fill_registration_form(data)

        start = time.perf_counter()

        page.submit_registration()

        response_time = (time.perf_counter() - start) * 1000

        save_metric(
            "registration_response",
            response_time
        )

        self.print_page_debug(
            driver,
            "РЕЗУЛЬТАТ УСПЕШНОЙ РЕГИСТРАЦИИ"
        )

        message = page.get_success_message()

        assert "created successfully" in message.lower()

    @allure.title("Негативный тест: пустое обязательное поле")
    @allure.description(
        "Проверка валидации обязательных полей регистрации"
    )
    @allure.severity(allure.severity_level.NORMAL)
    @pytest.mark.negative
    @pytest.mark.registration
    @pytest.mark.parametrize(
        "field, data_key",
        [
            ("firstName", "first_name"),
            ("lastName", "last_name"),
            ("address.street", "address"),
            ("address.city", "city"),
            ("address.state", "state"),
        ]
    )
    def test_empty_required_fields(
        self,
        driver,
        field,
        data_key
    ):

        data = get_registration_data()
        data[data_key] = ""

        page = RegistrationPage(driver)

        (
            page
            .open_registration()
            .fill_registration_form(data)
            .submit_registration()
        )

        assert page.has_field_error(field), (
            f"Не обнаружена ошибка обязательного поля: {field}"
        )

    @allure.title("Проверка несовпадения паролей")
    @allure.description(
        "Форма должна обнаруживать несовпадение паролей"
    )
    @allure.severity(allure.severity_level.CRITICAL)
    @pytest.mark.security
    @pytest.mark.registration
    def test_password_mismatch(self, driver):

        data = get_registration_data()

        data["confirm_password"] = "DifferentPass123!"

        page = RegistrationPage(driver)

        (
            page
            .open_registration()
            .fill_registration_form(data)
            .submit_registration()
        )

        self.print_page_debug(
            driver,
            "РЕЗУЛЬТАТ ПРОВЕРКИ НЕСОВПАДЕНИЯ ПАРОЛЕЙ"
        )

        assert page.has_field_error("repeatedPassword"), (
            "Форма не обнаружила несовпадение паролей"
        )
