
import csv
from pathlib import Path
from datetime import datetime

import allure


METRICS_FILE = Path("metrics/metrics.csv")


@allure.step("Сохранить метрику: {name}")
def save_metric(name, value):
    METRICS_FILE.parent.mkdir(parents=True, exist_ok=True)

    file_exists = METRICS_FILE.exists()

    with open(
        METRICS_FILE,
        "a",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.writer(file)

        if not file_exists:
            writer.writerow([
                "date",
                "metric",
                "value_ms"
            ])

        writer.writerow([
            datetime.now().isoformat(),
            name,
            round(value, 2)
        ])

    allure.attach(
        f"{name}: {value:.2f} ms",
        name=f"Metric: {name}",
        attachment_type=allure.attachment_type.TEXT
    )
