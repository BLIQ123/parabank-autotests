
import allure

from selenium.webdriver.common.by import By
from pages.base_page import BasePage


class RegistrationPage(BasePage):

    FIRST_NAME = (By.ID, "customer.firstName")
    LAST_NAME = (By.ID, "customer.lastName")
    ADDRESS = (By.ID, "customer.address.street")
    CITY = (By.ID, "customer.address.city")
    STATE = (By.ID, "customer.address.state")
    ZIP_CODE = (By.ID, "customer.address.zipCode")
    PHONE = (By.ID, "customer.phoneNumber")
    SSN = (By.ID, "customer.ssn")
    USERNAME = (By.ID, "customer.username")
    PASSWORD = (By.ID, "customer.password")
    CONFIRM_PASSWORD = (By.ID, "repeatedPassword")

    REGISTER_BUTTON = (
        By.XPATH,
        "//input[@value='Register']"
    )

    SUCCESS_MESSAGE = (
        By.XPATH,
        "//*[contains(text(),'Your account was created successfully')]"
    )

    ERROR_MESSAGE = (
        By.ID,
        "customer.username.errors"
    )

    @allure.step("Открыть страницу регистрации")
    def open_registration(self):
        self.open(
            "https://parabank.parasoft.com/parabank/register.htm"
        )
        return self

    @allure.step("Заполнить регистрационную форму")
    def fill_registration_form(self, data):

        fields = [
            (self.FIRST_NAME, data["first_name"]),
            (self.LAST_NAME, data["last_name"]),
            (self.ADDRESS, data["address"]),
            (self.CITY, data["city"]),
            (self.STATE, data["state"]),
            (self.ZIP_CODE, data["zip_code"]),
            (self.PHONE, data["phone"]),
            (self.SSN, data["ssn"]),
            (self.USERNAME, data["username"]),
            (self.PASSWORD, data["password"]),
            (self.CONFIRM_PASSWORD, data["confirm_password"])
        ]

        for locator, value in fields:
            self.fill(locator, value)

        return self

    @allure.step("Отправить форму регистрации")
    def submit_registration(self):
        self.click(self.REGISTER_BUTTON)
        return self

   
    @allure.step("Проверить наличие ошибки поля: {field}")
    def has_field_error(self, field):

        if field == "repeatedPassword":
            locator = (
                By.XPATH,
                "//*[contains(text(), 'Passwords did not match.')]"
            )
        else:
            locator = (
                By.ID,
                f"customer.{field}.errors"
            )

        try:
            return self.find(locator).is_displayed()
        except Exception:
            return False
    @allure.step("Получить сообщение об успешной регистрации")
    def get_success_message(self):
        return self.get_text(self.SUCCESS_MESSAGE)