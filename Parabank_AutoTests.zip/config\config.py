
import os

BASE_URL = os.getenv(
    "BASE_URL",
    "https://parabank.parasoft.com/"
)

BROWSER = os.getenv("BROWSER", "chrome").lower()

WAIT_TIMEOUT = 10

HEADLESS = os.getenv("HEADLESS", "false").lower() == "true"
