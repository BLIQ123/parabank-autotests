
import os
import json
import pytest
import allure

from datetime import datetime
from pathlib import Path

from selenium import webdriver
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions

from config.config import BASE_URL, WAIT_TIMEOUT, HEADLESS


@pytest.fixture(params=["chrome", "firefox"])
def browser_name(request):
    return request.param


@pytest.fixture
def driver(browser_name):
    browser = browser_name

    if browser == "chrome":
        options = ChromeOptions()

        options.set_capability(
            "goog:loggingPrefs",
            {
                "browser": "ALL",
                "performance": "ALL"
            }
        )

        if HEADLESS:
            options.add_argument("--headless=new")

        driver = webdriver.Chrome(options=options)

    elif browser == "firefox":
        options = FirefoxOptions()

        if HEADLESS:
            options.add_argument("-headless")

        driver = webdriver.Firefox(options=options)

    else:
        raise ValueError(f"Неизвестный браузер: {browser}")

    driver.implicitly_wait(0)
    driver.set_window_size(1366, 900)

    yield driver

    driver.quit()


@pytest.fixture
def base_url():
    return BASE_URL


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()

    if report.when != "call" or not report.failed:
        return

    driver = item.funcargs.get("driver")

    if driver is None:
        return

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    try:
        screenshot = driver.get_screenshot_as_png()

        allure.attach(
            screenshot,
            name=f"screenshot_{timestamp}",
            attachment_type=allure.attachment_type.PNG
        )
    except Exception:
        pass

    try:
        logs = driver.get_log("browser")

        allure.attach(
            json.dumps(logs, ensure_ascii=False, indent=2),
            name="browser_logs",
            attachment_type=allure.attachment_type.JSON
        )
    except Exception:
        pass

    try:
        if browser_name_from_driver(driver) == "chrome":
            network = driver.get_log("performance")

            allure.attach(
                json.dumps(network, ensure_ascii=False, indent=2),
                name="network_requests",
                attachment_type=allure.attachment_type.JSON
            )
    except Exception:
        pass


def browser_name_from_driver(driver):
    return driver.capabilities.get("browserName", "").lower()
