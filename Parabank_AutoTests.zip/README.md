# Parabank_AutoTests

## 1. Описание проекта

**Parabank_AutoTests** — проект автоматизированного тестирования веб-приложения Parabank с использованием Python, Selenium WebDriver и Pytest.

Проект предназначен для проверки функциональности регистрации пользователей, валидации полей и обработки ошибок.

Тестирование выполняется с использованием браузеров Google Chrome и Mozilla Firefox.

Сайт для тестирования: https://parabank.parasoft.com/

## 2. Используемые технологии

- Python 3.12
- Selenium WebDriver
- Pytest
- Allure Report 2.46.1
- WebDriver Manager
- Python Dotenv
- CSV для хранения метрик
- Google Chrome
- Mozilla Firefox
- Visual Studio Code

## 3. Структура проекта

```text
Parabank_AutoTests/
│
├── config/
│   ├── __init__.py
│   └── config.py
│
├── metrics/
│   ├── __init__.py
│   ├── metrics.py
│   └── metrics.csv
│
├── pages/
│   ├── __init__.py
│   ├── base_page.py
│   └── registration_page.py
│
├── reports/
│   ├── allure-results/
│   └── allure-report/
│
├── tests/
│   ├── __init__.py
│   ├── test_data.py
│   └── test_registration.py
│
├── venv/
│
├── conftest.py
├── pytest.ini
├── requirements.txt
└── README.md
```

## 4. Реализованные тесты

В проекте реализованы следующие проверки:

1. Успешная регистрация нового пользователя.
2. Проверка пустого имени.
3. Проверка пустой фамилии.
4. Проверка пустого адреса.
5. Проверка пустого города.
6. Проверка пустого штата.
7. Проверка несовпадения паролей.

Тестовые данные генерируются с уникальным именем пользователя.

## 5. Установка проекта

Создание виртуального окружения:

```powershell
py -3.12 -m venv venv
```

Активация:

```powershell
.\venv\Scripts\Activate.ps1
```

Установка зависимостей:

```powershell
pip install -r requirements.txt
```

## 6. Запуск тестов

Запуск всех тестов:

```powershell
python -m pytest -v
```

Запуск тестов Chrome:

```powershell
python -m pytest -v -k chrome
```

Запуск тестов с формированием результатов Allure:

```powershell
python -m pytest -v --alluredir=reports/allure-results --clean-alluredir
```

## 7. Формирование отчёта Allure

Генерация HTML-отчёта:

```powershell
& "C:\Tools\allure\bin\allure.bat" generate reports/allure-results -o reports/allure-report --clean
```

Открытие отчёта:

```powershell
& "C:\Tools\allure\bin\allure.bat" open reports/allure-report
```

## 8. Сбор метрик

В проекте предусмотрено сохранение показателей времени выполнения операций.

Результаты записываются в файл:

`metrics/metrics.csv`

Метрики позволяют анализировать производительность отдельных этапов тестирования.

## 9. Результаты тестирования

В ходе разработки были реализованы и проверены сценарии регистрации пользователей.

Последний зафиксированный результат Chrome:

- PASSED: 6
- FAILED: 1

Также предусмотрен запуск тестов Firefox, однако его работа требует дополнительной настройки драйвера.

## 10. Заключение

В результате разработки создан проект автоматизированного тестирования веб-приложения Parabank.

Реализованы:
- Page Object Model.
- Автоматизация браузерных действий.
- Позитивные и негативные тестовые сценарии.
- Генерация уникальных тестовых данных.
- Сбор метрик.
- Интеграция с Allure Report.

Проект может использоваться для дальнейшего расширения автоматизированного тестирования веб-приложений.
