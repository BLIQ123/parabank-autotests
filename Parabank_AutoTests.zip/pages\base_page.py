
import allure

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class BasePage:

    def __init__(self, driver, timeout=10):
        self.driver = driver
        self.wait = WebDriverWait(driver, timeout)

    @allure.step("Открыть страницу: {url}")
    def open(self, url):
        self.driver.get(url)
        return self

    @allure.step("Найти элемент: {locator}")
    def find(self, locator):
        return self.wait.until(
            EC.visibility_of_element_located(locator)
        )

    @allure.step("Нажать на элемент: {locator}")
    def click(self, locator):
        self.wait.until(
            EC.element_to_be_clickable(locator)
        ).click()
        return self

    @allure.step("Ввести текст: {text}")
    def fill(self, locator, text):
        element = self.find(locator)
        element.clear()
        element.send_keys(text)
        return self

    @allure.step("Получить текст элемента")
    def get_text(self, locator):
        return self.find(locator).text

    @allure.step("Получить текущий URL")
    def get_current_url(self):
        return self.driver.current_url
