
from datetime import datetime


def get_registration_data():
    unique_id = datetime.now().strftime("%Y%m%d%H%M%S")

    return {
        "first_name": "Test",
        "last_name": "User",
        "address": "Test Street 10",
        "city": "New York",
        "state": "NY",
        "zip_code": "10001",
        "phone": "1234567890",
        "ssn": "123456789",
        "username": f"testuser_{unique_id}",
        "password": "TestPass123!",
        "confirm_password": "TestPass123!"
    }
